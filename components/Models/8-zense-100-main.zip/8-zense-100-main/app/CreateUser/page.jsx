import UserForm from "../../app/CreateUser/page";

const CreateUser = () => {
  return (
    <div>
      <UserForm />
    </div>
  );
};

export default CreateUser;
